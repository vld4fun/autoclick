import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.InputEvent;
import java.io.IOException;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.FlowPane;
import javafx.stage.Stage;

public class JavaFxXApplication extends Application {

	UpdListener upd = new UpdListener();
	
	//private Button button;
	public static int rate = 5000;
	public static long ratePause = 500000000;
	boolean exit;
	//JavaFxXApplication udp = new JavaFxXApplication();
	//protected Runnable run;
	
	
	public void start(Stage primaryStage){
	    // creating the pane for the elements:
	    //FlowPane panel = new FlowPane();
	    Group panel = new Group();
	    Scene scene = new Scene(panel, 300, 250);
	  //creating the components:
	    Button buttonStart = new Button();
	    buttonStart.setText("Start");
	    buttonStart.setMaxSize(100,60);
	    buttonStart.setLayoutX(120);
	    buttonStart.setLayoutY(50);
	    
	    Button buttonStop = new Button();
	    buttonStop.setText("Stop");
	    buttonStop.setMaxSize(100,60);
	    buttonStop.setLayoutX(120);
	    buttonStop.setLayoutY(100);
	    
	    panel.getChildren().add(buttonStart);
	    panel.getChildren().add(buttonStop);
	    
	    // creating the scene with the FlowPane as the
	    // container for all elements and dimensions
	    // width = 300 and height = 250 pixels
	   
	    buttonStart.setOnAction(new EventHandler<ActionEvent>() {

            public void handle(ActionEvent event) {
            	exit = false;
            	//run();
            	new Thread(upd).start();
            	//Thread tr1 = new Thread();
            	//tr1.run();
            	System.out.println("Start");
            }
        });
	    
	    buttonStop.setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent event) {
            	exit = true;
            	System.out.println("Close");
            	//Thread.interrupted();
            	System.exit(0);
            	 
            }
        });
	    
	    
	    // setting the scene in the primary stage
	    primaryStage.setScene(scene);

	    // setting the title of the stage
	    primaryStage.setTitle("Test");

	    //displaying the stage
	    primaryStage.show();
	    
	}  

	public static void main(String[] args) {
		Application.launch();

	}

}
