import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.InputEvent;
import java.io.IOException;

public class UpdListener implements Runnable{
	public static int rate = 5000;
	//boolean exit;
	
	//JavaFxXApplication exxit = new JavaFxXApplication();
	//public boolean iesire(){
	//	return exxit.exit;
	//	}
		
	
	@Override
	public void run() {
		try {
            doProcessing();

        } catch (Exception e) {
        }
	}

		 public void doProcessing() throws IOException {
	    	 try {
	     		    Robot robot = new Robot();
	     		    while (true) { // exxit.exit == false
	     		        try {
	     		            Thread.sleep(rate);
	     		            robot.mousePress(InputEvent.BUTTON1_MASK);
	     		            robot.mouseRelease(InputEvent.BUTTON1_MASK);
	     		            } 
	     		        catch (InterruptedException ex) {} 
	     		        } 
	     		    } catch (AWTException e) {}
	    
	    }
}
