package neural;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class MethodClick extends AppClick {

	public static int rate = 5000;
	boolean loop;
	boolean exit; //exit = false;
	String start = "";
	
	public void ProgramInterface() {
	
	JFrame frame = new JFrame("AutoClickApp");
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    JButton closeButton = new JButton("Close");
//    JButton startButton = new JButton("Start");
//    startButton.setBounds(130,100,95,30);
    closeButton.setBounds(130,100,95,30);
 //   frame.add(startButton);
    frame.add(closeButton);
  //  Container contentPane = frame.getContentPane();
   // contentPane.add(closeButton);// w w w .ja v a2s . co  m
   // frame.pack();
    frame.setSize(400,300);  
    frame.setLayout(null); 
    frame.setVisible(true);
	
    
 /*    startButton.addActionListener(new ActionListener() {
    	public void actionPerformed(ActionEvent e) {
    		start.equals("Porneste");   
    	        }
    	    });
*/	   
    closeButton.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
        //exit = true;
        System.exit(0);
        }
    });
    
    
	try {
	    Robot robot = new Robot();
	    while (true) {
	        try {
	            Thread.sleep(rate);
	            robot.mousePress(InputEvent.BUTTON1_MASK);
	            robot.mouseRelease(InputEvent.BUTTON1_MASK);
	            } 
	        
	        catch (InterruptedException ex) {} 
	      //  exit = true;
	      //  if (exit == true) {
	       // 	 System.exit(0);
	        	//frame.dispatchEvent(new WindowEvent(frame, WindowEvent.WINDOW_CLOSING));
	      //  }
	 //  } 
	}	 
}
	catch (AWTException f) {} 
}
	    }

	

    
//        	 frame.dispatchEvent(new WindowEvent(frame, WindowEvent.WINDOW_CLOSING));
//         }    
//     });
//	}
//

   // 
    

 

	
